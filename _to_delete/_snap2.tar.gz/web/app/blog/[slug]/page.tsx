import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  buildMetadata,
  breadcrumbJsonLd,
  buildArticleJsonLd,
  faqJsonLd,
} from "@/lib/seo";
import { JsonLd } from "@/components/seo/json-ld";
import { BultenForm } from "@/components/bulten-form";
import { KapakYerTutucu } from "../_kapak";

const API_BASE =
  process.env.API_INTERNAL_URL ||
  process.env.NEXT_PUBLIC_API_URL ||
  "http://localhost:8000";

// Yeni yayınlanan makaleler kısa sürede görünsün.
export const revalidate = 300;
export const dynamicParams = true;

type Faq = { soru: string; cevap: string };
interface Makale {
  slug: string;
  title: string;
  excerpt?: string;
  body?: string;
  meta_title?: string;
  meta_description?: string;
  keywords?: string[];
  faq?: Faq[];
  author?: string;
  cover_image?: string | null;
  published_at?: string;
  updated_at?: string;
  editor_name?: string | null;
  editor_title?: string | null;
  reviewed_at?: string | null;
  sources?: string[];
}

async function getMakale(slug: string): Promise<Makale | null> {
  try {
    const res = await fetch(
      `${API_BASE}/api/icerik/makale/${encodeURIComponent(slug)}`,
      { next: { revalidate: 300 } }
    );
    if (!res.ok) return null;
    const json = await res.json();
    return (json?.data as Makale) ?? null;
  } catch {
    return null;
  }
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const m = await getMakale(params.slug);
  if (!m) return { robots: { index: false } };
  return buildMetadata({
    title: (m.meta_title || m.title).slice(0, 65),
    description:
      (m.meta_description || m.excerpt || m.title).slice(0, 170),
    path: `/blog/${m.slug}`,
    type: "article",
    keywords: m.keywords,
    publishedTime: m.published_at,
    modifiedTime: m.updated_at,
    authors: m.author ? [m.author] : undefined,
  });
}

// --- Hafif Markdown render (bağımlılıksız): ## h2, ### h3, - liste, **kalın**,
// [metin](url) link, > vurgu kutusu, ![açıklama](url){pozisyon} resim ---

// Admin panelde (icerik-panel.tsx) gövdeye eklenen resimler bu formatta gelir:
// ![açıklama](https://...) veya konum belirtilmişse ![açıklama](https://...){left|right|center|full}
const IMG_LINE_RE = /^!\[([^\]]*)\]\(([^)\s]+)\)(?:\{(left|right|center|full)\})?$/;

function resimKonumSinifi(pos: string): string {
  switch (pos) {
    case "left":
      return "float-left mr-6 mb-4 w-full sm:w-1/2";
    case "right":
      return "float-right ml-6 mb-4 w-full sm:w-1/2";
    case "full":
      return "w-full";
    default:
      return "mx-auto w-full sm:w-3/4";
  }
}
function inline(text: string, keyBase: string): React.ReactNode[] {
  // Önce [metin](url) linklerini ayır, kalan parçalarda **kalın** işle.
  const linkParts = text.split(/(\[[^\]]+\]\([^)]+\))/g);
  const out: React.ReactNode[] = [];
  let i = 0;
  for (const seg of linkParts) {
    const linkMatch = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(seg);
    if (linkMatch) {
      const [, label, href] = linkMatch;
      out.push(
        href.startsWith("/") ? (
          <Link key={`${keyBase}-l${i++}`} href={href} className="text-primary font-medium hover:underline">
            {label}
          </Link>
        ) : (
          <a
            key={`${keyBase}-l${i++}`}
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary font-medium hover:underline"
          >
            {label}
          </a>
        )
      );
      continue;
    }
    seg.split(/(\*\*[^*]+\*\*)/g).forEach((p) => {
      if (/^\*\*[^*]+\*\*$/.test(p)) {
        out.push(<strong key={`${keyBase}-b${i++}`}>{p.slice(2, -2)}</strong>);
      } else if (p) {
        out.push(<span key={`${keyBase}-s${i++}`}>{p}</span>);
      }
    });
  }
  return out;
}

function renderBody(body: string): React.ReactNode[] {
  const lines = (body || "").split(/\r?\n/);
  const nodes: React.ReactNode[] = [];
  let para: string[] = [];
  let list: string[] = [];
  let quote: string[] = [];
  let k = 0;

  const flushPara = () => {
    if (para.length) {
      nodes.push(<p key={`p-${k++}`}>{inline(para.join(" "), `p${k}`)}</p>);
      para = [];
    }
  };
  const flushList = () => {
    if (list.length) {
      nodes.push(
        <ul key={`ul-${k++}`} className="list-disc pl-5 space-y-1">
          {list.map((li, i) => (
            <li key={i}>{inline(li, `li${k}-${i}`)}</li>
          ))}
        </ul>
      );
      list = [];
    }
  };
  const flushQuote = () => {
    if (quote.length) {
      nodes.push(
        <div
          key={`bq-${k++}`}
          className="not-prose my-6 rounded-lg border border-primary/30 bg-primary/5 px-4 py-3 text-[0.95em]"
        >
          {inline(quote.join(" "), `bq${k}`)}
        </div>
      );
      quote = [];
    }
  };

  for (const raw of lines) {
    const line = raw.trimEnd();
    if (/^###\s+/.test(line)) {
      flushPara();
      flushList();
      flushQuote();
      nodes.push(
        <h3 key={`h3-${k++}`} className="text-lg font-semibold mt-6 mb-2">
          {line.replace(/^###\s+/, "")}
        </h3>
      );
    } else if (/^##\s+/.test(line)) {
      flushPara();
      flushList();
      flushQuote();
      nodes.push(
        <h2 key={`h2-${k++}`} className="text-2xl font-bold mt-8 mb-3">
          {line.replace(/^##\s+/, "")}
        </h2>
      );
    } else if (/^>\s+/.test(line)) {
      flushPara();
      flushList();
      quote.push(line.replace(/^>\s+/, ""));
    } else if (/^[-*]\s+/.test(line)) {
      flushPara();
      flushQuote();
      list.push(line.replace(/^[-*]\s+/, ""));
    } else if (IMG_LINE_RE.test(line.trim())) {
      flushPara();
      flushList();
      flushQuote();
      const [, alt, src, posRaw] = IMG_LINE_RE.exec(line.trim())!;
      const pos = posRaw || "center";
      nodes.push(
        <figure
          key={`img-${k++}`}
          className={`not-prose my-6 ${resimKonumSinifi(pos)}`}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={src}
            alt={alt}
            loading="lazy"
            className="w-full rounded-lg border object-cover"
          />
          {alt && (
            <figcaption className="mt-1.5 text-center text-xs text-muted-foreground">
              {alt}
            </figcaption>
          )}
        </figure>
      );
    } else if (line.trim() === "") {
      flushPara();
      flushList();
      flushQuote();
    } else {
      flushList();
      flushQuote();
      para.push(line);
    }
  }
  flushPara();
  flushList();
  flushQuote();
  // Sol/sağ hizalı (float) resimlerden sonra takip eden içeriğin (SSS, footer
  // notu vb.) görselle üst üste binmemesi için taşmayı temizle.
  nodes.push(<div key="clearfix" className="clear-both" />);
  return nodes;
}

export default async function BlogMakalePage({
  params,
}: {
  params: { slug: string };
}) {
  const m = await getMakale(params.slug);
  if (!m) notFound();

  const faqList = (m.faq || []).filter((f) => f.soru && f.cevap);

  return (
    <>
      <JsonLd
        data={[
          breadcrumbJsonLd([
            { name: "Ana Sayfa", url: "/" },
            { name: "Rehber", url: "/blog" },
            { name: m.title, url: `/blog/${m.slug}` },
          ]),
          buildArticleJsonLd({
            title: m.meta_title || m.title,
            description: m.meta_description || m.excerpt || m.title,
            path: `/blog/${m.slug}`,
            datePublished: m.published_at || new Date().toISOString(),
            dateModified: m.updated_at,
            authorName: m.author,
            editorName: m.editor_name || undefined,
            editorTitle: m.editor_title || undefined,
          }),
          ...(faqList.length
            ? [
                faqJsonLd(
                  faqList.map((f) => ({ question: f.soru, answer: f.cevap }))
                ),
              ]
            : []),
        ]}
      />
      <article className="container py-10 max-w-3xl">
        <nav className="text-sm text-muted-foreground mb-4">
          <Link href="/" className="hover:text-foreground">
            Ana Sayfa
          </Link>{" "}
          /{" "}
          <Link href="/blog" className="hover:text-foreground">
            Rehber
          </Link>{" "}
          / <span>{m.title}</span>
        </nav>

        <h1 className="text-3xl md:text-4xl font-bold mb-3">{m.title}</h1>
        {m.author && (
          <div className="text-sm text-muted-foreground mb-2">
            <p>
              {m.author}
              {m.published_at && (
                <>
                  {" · "}
                  {new Date(m.published_at).toLocaleDateString("tr-TR", {
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                  })}
                </>
              )}
              {m.updated_at && m.published_at && m.updated_at.slice(0, 10) !== m.published_at.slice(0, 10) && (
                <>
                  {" · güncelleme: "}
                  {new Date(m.updated_at).toLocaleDateString("tr-TR", {
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                  })}
                </>
              )}
            </p>
            {m.editor_name && (
              <p className="mt-1">
                İçerik incelemesi: <strong>{m.editor_name}</strong>
                {m.editor_title ? ` — ${m.editor_title}` : ""}
                {m.reviewed_at && (
                  <>
                    {" · "}
                    {new Date(m.reviewed_at).toLocaleDateString("tr-TR", {
                      day: "2-digit",
                      month: "long",
                      year: "numeric",
                    })}
                  </>
                )}
              </p>
            )}
          </div>
        )}

        <div className="mb-8 aspect-[16/9] w-full overflow-hidden rounded-xl border">
          {m.cover_image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={m.cover_image}
              alt=""
              className="h-full w-full object-cover"
            />
          ) : (
            <KapakYerTutucu slug={m.slug} />
          )}
        </div>

        {/* Okurken nefes alan bir düzen için: prose-sm yerine prose-base/lg
            (daha geniş paragraf boşluğu ve satır aralığı) + daha büyük
            eleman-arası boşluk. Önceki prose-sm çok sık/bitişik görünüyordu. */}
        <div className="prose prose-base md:prose-lg max-w-none leading-relaxed space-y-6">
          {renderBody(m.body || "")}
        </div>

        {faqList.length > 0 && (
          <section className="mt-10">
            <h2 className="text-2xl font-bold mb-4">Sıkça Sorulan Sorular</h2>
            <div className="space-y-3">
              {faqList.map((f, i) => (
                <div key={i} className="rounded-lg border bg-card p-4">
                  <h3 className="font-semibold mb-1.5 flex items-start gap-2">
                    <span className="text-accent">?</span>
                    {f.soru}
                  </h3>
                  <p className="text-muted-foreground text-sm">{f.cevap}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {m.sources && m.sources.length > 0 && (
          <section className="mt-10">
            <h2 className="text-lg font-semibold mb-2">Kaynakça</h2>
            <ul className="list-disc pl-5 space-y-1 text-sm text-muted-foreground">
              {m.sources.map((s, i) =>
                /^https?:\/\//.test(s) ? (
                  <li key={i}>
                    <a href={s} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline break-all">
                      {s}
                    </a>
                  </li>
                ) : (
                  <li key={i}>{s}</li>
                )
              )}
            </ul>
          </section>
        )}

        <p className="mt-8 text-xs text-muted-foreground">
          Bu içerik bilgilendirme amaçlıdır, hukuki danışmanlık değildir. Somut
          durumunuz için bir avukata danışın.
        </p>

        <BultenForm className="mt-10" />
      </article>
    </>
  );
}
